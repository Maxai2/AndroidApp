package com.example.papajohnsapp;

public class CategoryItem {
    int categId;
    String categName;

    CategoryItem(int categId, String categName) {
        this.categId = categId;
        this.categName = categName;
    }
}
